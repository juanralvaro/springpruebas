package com.certidevs;

import com.certidevs.model.Address;
import com.certidevs.model.Manufacturer;
import com.certidevs.model.Product;
import com.certidevs.repository.AddressRepository;
import com.certidevs.repository.ManufacturerRepository;
import com.certidevs.repository.ProductRepository;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@SpringBootApplication
public class Main {

	public static void main(String[] args) {
		// OPCIONAL: insertar datos demo

		// 1. Guardar el contexto de Spring en una variable
		// El contexto es como un contenedor de objetos de toda la aplicación
		var context = SpringApplication.run(Main.class, args);
		// 2. Con el método getBean() puedo obtener cualquier objeto de la aplicación
		ProductRepository productRepository = context.getBean(ProductRepository.class);

		// 3. Comprobar si existe algún producto
		long numeroProductos = productRepository.count();
		if (numeroProductos > 0)
			return;

		// Crear dos o tres productos y guardarlos en la base de datos
		var prod1 = Product.builder()
				.name("Zumo multifrutas").price(1.33).quantity(1).active(true).build();

		var prod2 = Product.builder()
				.name("Granola").price(4.33).quantity(4).active(false).build();

		productRepository.save(prod1);
		productRepository.save(prod2);


		//Crear objetos Manufacturer en la base de datos
		var manufacturerRepo = context.getBean(ManufacturerRepository.class);
		//Repositorio de address (copiar antes las direcciones)
		var addressRepo = context.getBean(AddressRepository.class);
		if (manufacturerRepo.count() == 0) {
			// Crear direcciones
			var address1 = Address.builder()
					.street("Calle Alfonso")
					.city("Zaragoza")
					.state("Aragón")
					.zipcode("50001")
					.build();
			var address2 = Address.builder()
					.street("Calle Córdoba")
					.city("Jaén")
					.state("Andalucía")
					.zipcode("23007")
					.build();
			// Insertar fabricantes

			var manufacturer1 = Manufacturer.builder()
					.name("Adidas")
					.description("description A")
					.year(2024)
					.imageUrl("https://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/Adidas_2022_logo.svg/1920px-Adidas_2022_logo.svg.png")
					.address(address1)
					.build();

			var manufacturer2 = Manufacturer.builder()
					.name("CertiDevs")
					.description("description A")
					.year(2024)
					.imageUrl("https://app.certidevs.com/content/images/CertiDevs-logo.svg")
					.address(address2)
					.build();

			manufacturerRepo.saveAll(
					List.of(manufacturer1, manufacturer2));
		}
	}

}
