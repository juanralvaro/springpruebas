package com.certidevs.controller;

import com.certidevs.model.Customer;
import com.certidevs.repository.CustomerRepository;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@AllArgsConstructor
@RestController
//@RequiredArgsConstructor
public class CustomerController {

    private CustomerRepository customerRepository;

    // Métodos GET
    // Método que nos devuelva un saludo

    @GetMapping("welcome") // localhost:8080/welcome
    public ResponseEntity<String> welcome() {
        return ResponseEntity.ok("Bienvenidos a un controlador de Spring");
    }

    // Método que captura un parámetro de la URL
    @GetMapping("user") // localhost:8080/user?name=Daniela
    public ResponseEntity<String> getUserName(@RequestParam String name) {
        return ResponseEntity.ok("Welcome user " + name);
    }

    // Métodos CRUD
    // Método que nos devuelva todos los clientes
    @GetMapping("customers") // localhost:8080/customers
    public ResponseEntity<List<Customer>> findAll() {
        return ResponseEntity.ok(customerRepository.findAll());
    }

    // Método que devuelva un cliente por su ID
    @GetMapping("customers/{id}") // localhost:8080/customers/1
    public ResponseEntity<Customer> findById(@PathVariable Long id) {
        return customerRepository.findById(id)
                .map(customer -> {
                    return ResponseEntity.ok(customer);
                })
                .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND).build());
    }

    // Método POST
    // Método que nos permite crear un nuevo cliente

    @PostMapping("customers")
    public ResponseEntity<Customer> create(@RequestBody Customer customer) {
        if(customer.getId() != null)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST);

        customerRepository.save(customer); // obtiene un ID
        return ResponseEntity.status(HttpStatus.CREATED).body(customer);
    }

    // Método PUT
    // Método que nos permite crear un nuevo cliente

    @PutMapping("customers")
    public ResponseEntity<Customer> edit(@RequestBody Customer customer) {
        if(customer.getId() == null)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST);

        customerRepository.save(customer); // obtiene un ID
        return ResponseEntity.ok(customer);
    }

    // Método DELETE
    // Método que nos permite eliminar un cliente

    @DeleteMapping("customers/{id}")
    public ResponseEntity<Void> deleteById(@PathVariable Long id) {
        try {
            customerRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.CONFLICT);
        }
    }

}
